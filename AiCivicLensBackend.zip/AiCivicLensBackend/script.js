document.getElementById("fetchDataBtn").addEventListener("click", async () => {
  const responseMessage = document.getElementById("responseMessage");
  responseMessage.textContent = "Fetching data...";

  try {
    const res = await fetch(
      "https://15f72860-11d1-42c0-a053-000d462e1f44-00-3rvyo8q9xecfp.janeway.replit.dev/users",
    );
    const data = await res.json();
    responseMessage.textContent = data.message || "Connected successfully!";
  } catch (error) {
    responseMessage.textContent = "Error connecting to backend.";
    console.error(error);
  }
});
