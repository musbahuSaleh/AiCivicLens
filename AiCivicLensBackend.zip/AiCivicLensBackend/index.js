import express from "express";
import cors from "cors";

const app = express();
app.use(express.json());
app.use(cors());

// --- Example routes ---
app.get("/", (req, res) => {
  res.send("✅ Ai CivicLens backend is running successfully!");
});

app.get("/api/users", (req, res) => {
  res.json([
    { id: 1, name: "Musbahu Saleh" },
    { id: 2, name: "Test User" },
  ]);
});

app.get("/api/reports", (req, res) => {
  res.json([
    { id: 1, title: "Report on Human Trafficking" },
    { id: 2, title: "Climate and Energy Report" },
  ]);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
