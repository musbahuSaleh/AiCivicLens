const backendURL =
  "https://15f72860-11d1-42c0-a053-000d462e1f44-00-3rvyo8q9xecfp.janeway.replit.dev";

document.getElementById("getDataBtn").addEventListener("click", async () => {
  const result = document.getElementById("result");
  result.innerText = "Loading data...";

  try {
    // Fetch data from backend
    const [helloRes, reportsRes, insightsRes, statsRes] = await Promise.all([
      fetch(`${backendURL}/api/data`),
      fetch(`${backendURL}/api/reports`),
      fetch(`${backendURL}/api/insights`),
      fetch(`${backendURL}/api/stats`),
    ]);

    const hello = await helloRes.json();
    const reports = await reportsRes.json();
    const insights = await insightsRes.json();
    const stats = await statsRes.json();

    // Display greeting
    result.innerText = hello.message;

    // Display Civic Reports
    const reportsSection = document.querySelector(".section:nth-of-type(1)");
    reportsSection.innerHTML = `
      <h2>Civic Reports</h2>
      <ul>
        ${reports.map((r) => `<li>${r.title} – ${r.location} (${r.status})</li>`).join("")}
      </ul>
    `;

    // Display AI Insights
    const insightsSection = document.querySelector(".section:nth-of-type(2)");
    insightsSection.innerHTML = `
      <h2>AI Insights</h2>
      <p><b>Summary:</b> ${insights.summary}</p>
      <p><b>Sentiment:</b> ${insights.sentiment}</p>
      <p><b>Key Topics:</b> ${insights.keyTopics.join(", ")}</p>
    `;

    // Display Engagement Stats
    const statsSection = document.querySelector(".section:nth-of-type(3)");
    statsSection.innerHTML = `
      <h2>Engagement Stats</h2>
      <p><b>Total Reports:</b> ${stats.totalReports}</p>
      <p><b>Resolved:</b> ${stats.resolved}</p>
      <p><b>Active Users:</b> ${stats.activeUsers}</p>
      <p><b>Satisfaction:</b> ${stats.satisfaction}</p>
    `;
  } catch (error) {
    result.innerText = "Error fetching data.";
    console.error("Fetch error:", error);
  }
});
