import express from "express";
import cors from "cors";

const app = express();

// ✅ Middleware
app.use(cors());
app.use(express.json());

// ✅ Root route
app.get("/", (req, res) => {
  res.send("Welcome to Ai CivicLens API!");
});

// ✅ Basic test route
app.get("/api/data", (req, res) => {
  res.json({ message: "Hello from AiCivicLens backend!" });
});

// ✅ Civic Reports Route
app.get("/api/reports", (req, res) => {
  res.json([
    { title: "Road Repair Needed", location: "Kano", status: "Pending" },
    { title: "Water Supply Issue", location: "Hadejia", status: "Resolved" },
  ]);
});

// ✅ AI Insights Route
app.get("/api/insights", (req, res) => {
  res.json({
    summary: "Citizen participation increased by 25% this month.",
    sentiment: "Positive",
    keyTopics: ["Transparency", "Community", "Engagement"],
  });
});

// ✅ Engagement Stats Route
app.get("/api/stats", (req, res) => {
  res.json({
    totalReports: 128,
    resolved: 95,
    activeUsers: 456,
    satisfaction: "89%",
  });
});

// ✅ Use Replit or local port
const PORT = process.env.PORT || 5000;

// ✅ Start server
app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
