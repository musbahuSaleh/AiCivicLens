import express from "express";
import cors from "cors";

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static("."));

// ✅ Main greeting endpoint
app.get("/api/data", (req, res) => {
  res.json({ message: "Hello from AiCivicLens backend!" });
});

// ✅ Civic Reports endpoint
app.get("/api/reports", (req, res) => {
  res.json([
    {
      id: 1,
      title: "Human Trafficking Report",
      location: "Kano",
      status: "Resolved",
    },
    {
      id: 2,
      title: "Climate and Energy Report",
      location: "Jigawa",
      status: "Pending",
    },
    {
      id: 3,
      title: "Youth Empowerment Project",
      location: "Abuja",
      status: "In Progress",
    },
  ]);
});

// ✅ AI Insights endpoint
app.get("/api/insights", (req, res) => {
  res.json({
    summary:
      "Public engagement on governance has increased by 25% in the last quarter.",
    sentiment: "Positive",
    keyTopics: ["Governance", "Climate", "Youth Participation"],
  });
});

// ✅ Engagement Stats endpoint
app.get("/api/stats", (req, res) => {
  res.json({
    totalReports: 45,
    resolved: 30,
    activeUsers: 120,
    satisfaction: "85%",
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server running on http://0.0.0.0:${PORT}`);
});
